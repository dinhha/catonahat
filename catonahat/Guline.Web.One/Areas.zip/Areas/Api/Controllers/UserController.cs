﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Guline.Web.One.Controllers;
using Guline.Web.One.DInject;

namespace Guline.Web.One.Areas.Api.Controllers
{
    public class UserController : GulineController
    {
        private readonly IUserService _userService;
        public UserController(IUserService userservice)
        {
            _userService = userservice;
        }
        [HttpPost]
        public ActionResult Login(string username, string password, bool remember = false)
        {
            var u = _userService.findByEmailPassword(username, password);

            if (u != null)
            {
                FormsAuthentication.SetAuthCookie(username, remember);

                return Json(new { success = true, data = new { u.Email, u.GroupID, u.GroupName } }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { success = false, msg = "Wrong username or password.", errorcode = 1 }, JsonRequestBehavior.AllowGet);
            }
        }
       
        public ActionResult Party(string token)
        {
            try
            {
                string refurl = Request.UrlReferrer.Host;
                var organize = _userService.findOrganize(refurl);

                string maintxt = gModels.SSTCryptographer.Decrypt(token,organize.TokenKey);
               
                if (maintxt!="OK")
                {
                    return Json(new { success = false, msg = "Access denied.references:"+refurl }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                   
                    if (organize == null)
                    {
                        return Json(new { success = false, msg = "Access denied, You should register services with Quadate.com - Guline Solutions." }, JsonRequestBehavior.AllowGet);
                    }
                    Session["Organize"] = organize;
                    return RedirectToAction("Index", "Admin", new { area = System.Configuration.ConfigurationManager.AppSettings["AdminUrlStart"] });
                }

            }
            catch
            {
                return Json(new { success = false, msg = "Access denied, You should register services with Quadate.com - Guline Solutions." }, JsonRequestBehavior.AllowGet);
            }
            
        }
   
        public ActionResult Logout()
        {
            Session["Organize"] = null;
            return Json(new { success = true }, JsonRequestBehavior.AllowGet);
        }
    }
}
