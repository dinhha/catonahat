﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Guline.Web.One.Controllers;
using Guline.Web.One.DInject;
using System.Net.Mail;
using Guline.Web.One.gModels;
using Newtonsoft.Json;

namespace Guline.Web.One.Areas.Api.Controllers
{

    public class ObjectController : GulineController
    {
        private IObjectGroup sc;
        public ObjectController(IObjectGroup service)
        {
            sc = service;
        }

        public ActionResult ListObject(int page = 1, int pagesize = 10)
        {

            var listobjects = sc.Listing(page, pagesize, Organize.ID);
            return Json(new { success = true, Data = listobjects }, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetListObjectData(string objectname, string filters, string orderbys, int page = 1, int pagesize = 10)
        {
            var listobjects = sc.getListObject(objectname, filters, orderbys, page, pagesize, Organize.ID);
            return Json(new { success = true, data = listobjects }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult findObject(string objectname, long ID)
        {
            var objbase = sc.findObject(objectname, ID, Organize.ID);
            if (objbase == null)
            {
                return Json(new { success = false, msg = "object not found." }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { success = true, data = objbase }, JsonRequestBehavior.AllowGet);

            }
        }
        public ActionResult GetOneBaseObject(string objectname)
        {
            var objbase = sc.getOneBaseObject(objectname, Organize.ID);
            if (objbase == null)
            {
                return Json(new { success = false, msg = "object not found." }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                if (objbase.hasChild)
                {
                    return Json(new { success = true, data = objbase, parents = sc.parentList(objectname, 0, Organize.ID) }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { success = true, data = objbase }, JsonRequestBehavior.AllowGet);
                }


            }
        }
        public ActionResult GetObjectListTile(string objectname)
        {
            var objbase = sc.ListObjectTitle(objectname, Organize.ID);
            return Json(new { success = true, data = objbase }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetOneObject(string objectname)
        {
            var objbase = sc.getOneObject(objectname, Organize.ID);
            if (objbase == null)
            {
                return Json(new { success = false, msg = "object not found." }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { success = true, data = objbase }, JsonRequestBehavior.AllowGet);

            }
        }
        [HttpPost]
        public ActionResult UpdateOneObject(gModels.gObject model)
        {
            return Json(new { success = true, data = sc.UpdateOneModel(model, Organize.ID) });
        }

        //send mail

        public ActionResult SendMail(SendMail model)
        {

            var mailconfig = sc.getOneObject("mailconfig", Organize.ID);
            if (mailconfig == null)
                return Json(new { success = false, msg = "You should config mail sender first." }, JsonRequestBehavior.AllowGet);

            var config = mailconfig.Attrs.ToDictionary(m => m.AttrName, m => m.AttrValue);
            try
            {
                var template = sc.findObject("mailtemplate", model.TemplateID, Organize.ID);
                if (template == null)
                    return Json(new { success = false, msg = "Template not found" }, JsonRequestBehavior.AllowGet);

                var SmtpServer = new SmtpClient(config["host"]);
                SmtpServer.Port = int.Parse(config["port"]);
                SmtpServer.Credentials = new System.Net.NetworkCredential(config["user"], config["password"]);
                SmtpServer.EnableSsl = true;



                List<Receiver> listerror = new List<Receiver>();
                List<gModels.gObjectAttr> listAttr = new List<gObjectAttr>();
                string recevers = "";
                foreach (var receiver in model.Receivers)
                {
                    try
                    {
                        var email = new GuMail();
                        email.mSmtp = SmtpServer;
                        email.From = config["user"];
                        //get email template
                        var templateconfig = template.Attrs.ToDictionary(m => m.AttrName, m => m.AttrValue);
                        email.Title = template.Title;
                        email.ContentText = templateconfig["shortdescription"];
                        email.ContentHtml = templateconfig["mailcontent"];
                        email.To = receiver.text;
                        email.Send();
                        if (recevers != "") recevers += "," + receiver.text;
                        else recevers += receiver.text;


                    }
                    catch
                    {
                        listerror.Add(receiver);
                    }
                }
                listAttr.Add(new gModels.gObjectAttr() {ID=9 ,AttrValue = recevers, gObjectGroupID = 3, Status = 1, CreateDate = DateTime.Now, AttrType = 17 });
                listAttr.Add(new gModels.gObjectAttr() { ID = 11, AttrValue = JsonConvert.SerializeObject(template), gObjectGroupID = 3, Status = 1, CreateDate = DateTime.Now, AttrType = 4 });
                //hh
                sc.UpdateOneModel(new gObject()
                {
                    Title = template.Title,
                    CreateDate = DateTime.Now,
                    Status = 1,
                    gGroupID = 3,
                    Slug = template.Slug,
                    Attrs = listAttr
                }, Organize.ID);
                return Json(new { success = true, error = listerror }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                return Json(new { success = false, mgs = ex.Message }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}
